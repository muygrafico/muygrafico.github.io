<?php

include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');

$smarty->assign(array('this_path' => __PS_BASE_URI__));
$smarty->display(_PS_MODULE_DIR_.'pagodigital/pago_correcto.tpl');

include(dirname(__FILE__).'/../../footer.php');

?>
