<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{pagodigital}prestashop>pagodigital_d7d0015d35ad2c792f9e399e98bd40e1'] = 'Credit card payment. Safe connection via pagodigital.';
