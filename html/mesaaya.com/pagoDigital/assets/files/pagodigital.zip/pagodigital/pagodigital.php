<?php


if (!defined('_CAN_LOAD_FILES_'))
	exit;

class pagodigital extends PaymentModule
{
	private	$_html = '';
	private $_postErrors = array();

	public function __construct(){
		$this->name = 'pagodigital';
		$this->tab = 'payments_gateways';
		$this->version = '1.0';

		// Array config con los datos de configuración
		$config = Configuration::getMultiple(array('pagodigital_URLTPV', 'pagodigital_CLAVE', 'pagodigital_NOMBRE', 'pagodigital_CODIGO','pagodigital_TIPOPAGO','pagodigital_TERMINAL','pagodigital_CLAVEPG','pagodigital_TIPOFIRMA', 'pagodigital_MONEDA', 'pagodigital_TRANS', 'pagodigital_NOTIFICACION', 'pagodigital_SSL', 'pagodigital_ERROR_PAGO', 'pagodigital_IDIOMAS_ESTADO'));
		// Establecer propiedades según los datos de configuración
		$this->env = $config['pagodigital_URLTPV'];
		switch($this->env){
			case 1: //Real
				$this->urltpv = "https://www.pagodigital.co/gateway/index.php";
				break;
			case 2: //Pruebas t
				$this->urltpv = "https://www.pagodigital.co";
				break;
			case 3: // Pruebas i
				$this->urltpv = "https://www.pagodigital.co";
				break;
			case 4: //Pruebas d
				$this->urltpv = "https://www.pagodigital.co";
				break;
		}
		$this->clave = $config['pagodigital_CLAVE'];
		if (isset($config['pagodigital_NOMBRE']))
			$this->nombre = $config['pagodigital_NOMBRE'];
		if (isset($config['pagodigital_CODIGO']))
			$this->codigo = $config['pagodigital_CODIGO'];
		if (isset($config['pagodigital_TIPOPAGO']))
			$this->tipopago = $config['pagodigital_TIPOPAGO'];
		if (isset($config['pagodigital_TERMINAL']))
			$this->terminal = $config['pagodigital_TERMINAL'];
		if (isset($config['pagodigital_CLAVEPG']))
			$this->clavepg = $config['pagodigital_CLAVEPG'];
		if (isset($config['pagodigital_TIPOFIRMA']))
			$this->tipofirma = $config['pagodigital_TIPOFIRMA'];
	//	if (isset($config['pagodigital_RECARGO']))
			//$this->recargo = $config['pagodigital_RECARGO'];
		if (isset($config['pagodigital_MONEDA']))
			$this->moneda = $config['pagodigital_MONEDA'];
		if (isset($config['pagodigital_TRANS']))
			$this->trans = $config['pagodigital_TRANS'];
		//if (isset($config['pagodigital_NOTIFICACION']))
			//$this->notificacion = $config['pagodigital_NOTIFICACION'];
		//if (isset($config['pagodigital_SSL']))
			//$this->ssl = $config['pagodigital_SSL'];
		//if (isset($config['pagodigital_ERROR_PAGO']))
			//$this->error_pago = $config['pagodigital_ERROR_PAGO'];
		//if (isset($config['pagodigital_IDIOMAS_ESTADO']))
			//$this->idiomas_estado = $config['pagodigital_IDIOMAS_ESTADO'];


		parent::__construct();

		$this->page = basename(__FILE__, '.php');
		$this->displayName = $this->l('pagodigital');
		$this->description = $this->l('Aceptar pagos con tarjeta mediante pagodigital');

		// Mostrar aviso en la página principal de módulos si faltan datos de configuración.
		if (!isset($this->urltpv)
		OR !isset($this->clave)
		OR !isset($this->nombre)
		OR !isset($this->codigo)
		OR !isset($this->tipopago)
		OR !isset($this->terminal)
		OR !isset($this->clavepg)
		OR !isset($this->moneda))
		//OR !isset($this->tipofirma)
		//OR !isset($this->recargo)
		//OR !isset($this->trans)
		//OR !isset($this->notificacion)
		//OR !isset($this->ssl)
	    //OR !isset($this->error_pago)
		//OR !isset($this->idiomas_estado))


		$this->warning = $this->l('Faltan datos por configurar del mod. pagodigital.');
	}

	public function install()
	{
		// Valores por defecto al instalar el módulo
		if (!parent::install()
			OR !Configuration::updateValue('pagodigital_URLTPV', '0')
			OR !Configuration::updateValue('pagodigital_NOMBRE', $this->l('Escriba el nombre de su tienda'))
			OR !Configuration::updateValue('pagodigital_TIPOPAGO','T')
			OR !Configuration::updateValue('pagodigital_TERMINAL', 1)
			//OR !Configuration::updateValue('pagodigital_CLAVEPG', 1)
			OR !Configuration::updateValue('pagodigital_TIPOFIRMA', 0)
			OR !Configuration::updateValue('pagodigital_MONEDA', '978')
			OR !Configuration::updateValue('pagodigital_TRANS', 0)
			OR !$this->registerHook('payment')
			OR !$this->registerHook('paymentReturn'))
			//OR !Configuration::updateValue('pagodigital_RECARGO', '00')
			//OR !Configuration::updateValue('pagodigital_NOTIFICACION', 0)
			//OR !Configuration::updateValue('pagodigital_SSL', 'no')
			//OR !Configuration::updateValue('pagodigital_ERROR_PAGO', 'no')
			//OR !Configuration::updateValue('pagodigital_IDIOMAS_ESTADO', 'no')
			
			return false;
		return true;
	}

	public function uninstall()
	{
	   // Valores a quitar si desinstalamos el módulo
		if (!Configuration::deleteByName('pagodigital_URLTPV')
			OR !Configuration::deleteByName('pagodigital_CLAVE')
			OR !Configuration::deleteByName('pagodigital_NOMBRE')
			OR !Configuration::deleteByName('pagodigital_CODIGO')
			OR !Configuration::deleteByName('pagodigital_TIPOPAGO')
			OR !Configuration::deleteByName('pagodigital_TERMINAL')
			OR !Configuration::deleteByName('pagodigital_CLAVEPG')
			OR !Configuration::deleteByName('pagodigital_TIPOFIRMA')
			//OR !Configuration::deleteByName('pagodigital_RECARGO')
			OR !Configuration::deleteByName('pagodigital_MONEDA')
			OR !Configuration::deleteByName('pagodigital_TRANS')
			//OR !Configuration::deleteByName('pagodigital_NOTIFICACION')
			//OR !Configuration::deleteByName('pagodigital_SSL')
			//OR !Configuration::deleteByName('pagodigital_ERROR_PAGO')
			//OR !Configuration::deleteByName('pagodigital_IDIOMAS_ESTADO')
			OR !parent::uninstall())
			return false;
		return true;
	}

	private function _postValidation(){
	    // Si al enviar los datos del formulario de configuración hay campos vacios, mostrar errores.
		if (isset($_POST['btnSubmit'])){
			if (empty($_POST['clave']))
				$this->_postErrors[] = $this->l('Se requiere la Clave secreta de Usuario.');
			if (empty($_POST['clavepg']))
				$this->_postErrors[] = $this->l('Se requiere la Clave secreta de Pago Digital.');
			if (empty($_POST['nombre']))
				$this->_postErrors[] = $this->l('Se requiere el Nombre del comercio.');
			if (empty($_POST['tipopago']))
				$this->_postErrors[] = $this->l('Se requiere el Nombre del comercio.');
			if (empty($_POST['codigo']))
				$this->_postErrors[] = $this->l('Se requiere el Num. de comercio (Pago Digital).');
			if (empty($_POST['terminal']))
				$this->_postErrors[] = $this->l('Se requiere el Terminal del comercio (Pago Digital).');
			//if (empty($_POST['redireccion']))
				//$this->_postErrors[] = $this->l('Se requiere la URL de Redireccion');
			//if (empty($_POST['recargo']))
				//$this->_postErrors[] = $this->l('Si no desea aplicar recargo, ponga 00.');
			if (empty($_POST['moneda']))
				$this->_postErrors[] = $this->l('Se requiere el Tipo de moneda.');

		}
	}

	private function _postProcess(){
	    // Actualizar la configuración en la BBDD
			if (isset($_POST['btnSubmit'])){
			Configuration::updateValue('pagodigital_URLTPV', $_POST['urltpv']);
			Configuration::updateValue('pagodigital_CLAVE', $_POST['clave']);
			Configuration::updateValue('pagodigital_NOMBRE', $_POST['nombre']);
			Configuration::updateValue('pagodigital_CODIGO', $_POST['codigo']);
			Configuration::updateValue('pagodigital_TIPOPAGO', $_POST['tipopago']);
			Configuration::updateValue('pagodigital_TERMINAL', $_POST['terminal']);
			Configuration::updateValue('pagodigital_CLAVEPG', $_POST['clavepg']);
			Configuration::updateValue('pagodigital_TIPOFIRMA', $_POST['tipofirma']);
			//Configuration::updateValue('pagodigital_RECARGO', $_POST['recargo']);
			Configuration::updateValue('pagodigital_MONEDA', $_POST['moneda']);
			Configuration::updateValue('pagodigital_TRANS', $_POST['trans']);
			//Configuration::updateValue('pagodigital_NOTIFICACION', $_POST['notificacion']);
			//Configuration::updateValue('pagodigital_SSL', $_POST['ssl']);
			//Configuration::updateValue('pagodigital_ERROR_PAGO', $_POST['error_pago']);
			//Configuration::updateValue('pagodigital_IDIOMAS_ESTADO', $_POST['idiomas_estado']);
		}

		$this->_html .= '<div class="conf confirm"><img src="../img/admin/ok.gif" alt="'.$this->l('ok').'" /> '.$this->l('Configuraci&oacute;n actualizada').'</div>';
	}

	private function _displaypagodigital()
	{
	    // Aparición el la lista de módulos
		$this->_html .= '<img src="../modules/pagodigital/pagodigital.png" style="float:left; margin-right:15px;"><b>'.$this->l('Este m&oacute;dulo te permite aceptar pagos con tarjeta.').'</b><br /><br />
		'.$this->l('Si el cliente elije este modo de pago, podr&aacute; pagar de forma autom&aacute;tica.').'<br /><br /><br />';
	}

	private function _displayForm(){

	
		$tipopago = Tools::getValue('tipopago', $this->tipopago);
		$tipopago_a =  ($tipopago == ' ') ? ' selected="selected" ' : '';
		$tipopago_b = ($tipopago == 'C') ? ' selected="selected" ' : '';
		$tipopago_c = ($tipopago == 'T') ? ' selected="selected" ' : '';
	
		// Opciones para el select de monedas.
		$moneda = Tools::getValue('moneda', $this->moneda);
		$iseuro =  ($moneda == '978') ? ' selected="selected" ' : '';
		$isdollar = ($moneda == '840') ? ' selected="selected" ' : '';

		// Opciones para activar/desactivar SSL
		//$ssl = Tools::getValue('ssl', $this->ssl);
		//$ssl_si = ($ssl == 'si') ? ' checked="checked" ' : '';
		//$ssl_no = ($ssl == 'no') ? ' checked="checked" ' : '';

		// Opciones para el comportamiento en error en el pago
		//$error_pago = Tools::getValue('error_pago', $this->error_pago);
		//$error_pago_si = ($error_pago == 'si') ? ' checked="checked" ' : '';
		//$error_pago_no = ($error_pago == 'no') ? ' checked="checked" ' : '';

		// Opciones para activar los idiomas
		//$idiomas_estado = Tools::getValue('idiomas_estado', $this->idiomas_estado);
		//$idiomas_estado_si = ($idiomas_estado == 'si') ? ' checked="checked" ' : '';
		//$idiomas_estado_no = ($idiomas_estado == 'no') ? ' checked="checked" ' : '';

		// Opciones entorno
		if (!isset($_POST['urltpv']))
			$entorno = Tools::getValue('env', $this->env);
				else
					$entorno = $_POST['urltpv'];
		$entorno_real =  ($entorno==1) ? ' selected="selected" ' : '';
		$entorno_t =  ($entorno==2) ? ' selected="selected" ' : '';
		$entorno_i =  ($entorno==3) ? ' selected="selected" ' : '';
		$entorno_d =  ($entorno==4) ? ' selected="selected" ' : '';

		// Opciones tipofirma
		$tipofirma = Tools::getValue('tipofirma', $this->tipofirma);
	  	$tipofirma_a =  ($tipofirma==0) ? ' checked="checked" ' : '';
	  	$tipofirma_c =  ($tipofirma==1) ? ' checked="checked" '  : '';

	    // Opciones notificacion
	    //$notificacion = Tools::getValue('notificacion', $this->notificacion);
		//$notificacion_s =  ($notificacion==1) ? ' checked="checked" '  : '';
		//$notificacion_n =  ($notificacion==0) ? ' checked="checked" '  : '';

		// Mostar formulario
		$this->_html .=
		'<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
			<fieldset>
			<legend><img src="../img/admin/contact.gif" />'.$this->l('Configuraciones de Pago Digital').'</legend>
				<table border="0" width="680" cellpadding="0" cellspacing="0" id="form">
					<tr><td colspan="2">'.$this->l('Por favor completa los datos de configuración del comercio').'.<br /><br /></td></tr>
					<tr><td width="215" style="height: 35px;">'.$this->l('Entorno de pagodigital').'</td><td><select name="urltpv"><option value="1"'.$entorno_real.'>'.$this->l('Real').'</option><option value="2"'.$entorno_t.'>'.$this->l('Pruebas').'</option></select></td></tr>
					<tr><td width="215" style="height: 35px;">'.$this->l('Nombre del comercio').'</td><td><input type="text" name="nombre" value="'.htmlentities(Tools::getValue('nombre', $this->nombre), ENT_COMPAT, 'UTF-8').'" style="width: 200px;" /></td></tr>
					<tr><td width="215" style="height: 35px;">'.$this->l('Numero de Comercio (Pago Digital)').'</td><td><input type="text" name="codigo" value="'.Tools::getValue('codigo', $this->codigo).'" style="width: 200px;" /></td></tr>
					<tr><td width="215" style="height: 35px;">'.$this->l('Tipos de pago permitidos').'</td><td><select name="tipopago" style="width: 120px;"><option value=""></option><option value="C"'.$tipopago_b.'>Solo con Tarjeta</option></select></td></tr>
					<tr><td width="215" style="height: 35px;">'.$this->l('Clave Pública de comercio').'</td><td><input type="text" name="clave" value="'.Tools::getValue('clave', $this->clave).'" style="width: 200px;" /></td></tr>
					<tr><td width="215" style="height: 35px;">'.$this->l('Clave Privada de Pago Digital').'</td><td><input type="text" name="clavepg" value="'.Tools::getValue('clavepg', $this->clavepg).'" style="width: 200px;" /></td></tr>						
					<tr><td width="215" style="height: 35px;">'.$this->l('Numero de terminal').'</td><td><input type="text" name="terminal" value="'.Tools::getValue('terminal', $this->terminal).'" style="width: 80px;" /></td></tr>
					<tr><td width="215" style="height: 35px;">'.$this->l('Tipo de moneda').'</td><td><select name="moneda" style="width: 80px;"><option value=""></option><option value="978"'.$iseuro.'>COP</option></select></td></tr>
	    </td></tr>
				</table>
			</fieldset>
			<br>
			<br>
		<input class="button" name="btnSubmit" value="'.$this->l('Guardar configuraci&oacute;n').'" type="submit" />
		</form>';
	}

	public function getContent()
	{
	    // Recoger datos
		$this->_html = '<h2>'.$this->displayName.'</h2>';
		if (!empty($_POST))
		{
			$this->_postValidation();
			if (!sizeof($this->_postErrors))
				$this->_postProcess();
			else
				foreach ($this->_postErrors AS $err)
					$this->_html .= '<div class="alert error">'. $err .'</div>';
		}
		else
			$this->_html .= '<br />';
		$this->_displaypagodigital();
		$this->_displayForm();
		return $this->_html;
	}

	public function hookPayment($params)
	{
		// Variables necesarias de fuera
		global $smarty, $cookie, $cart;

		// Aplicar Recargo
		//$porcientorecargo = Tools::getValue('recargo', $this->recargo);
		//$porcientorecargo = str_replace (',','.',$porcientorecargo);
		//$totalcompra = floatval($cart->getOrderTotal(true, 3));
		//$fee = ($porcientorecargo / 100) * $totalcompra;


		// Valor de compra
		$id_currency = intval(Configuration::get('PS_CURRENCY_DEFAULT'));
		$currency = new Currency(intval($id_currency));
		$cantidad = number_format(Tools::convertPrice($params['cart']->getOrderTotal(true, 3) + $fee, $currency), 2, '.', '');
		$cantidad = str_replace('.','',$cantidad);
		$cantidad = floatval($cantidad);

		// El número de pedido es  los 8 ultimos digitos del ID del carrito + el tiempo MMSS.
		$numpedido = str_pad($params['cart']->id, 8, "0", STR_PAD_LEFT) . date("is");

		$codigo = Tools::getValue('codigo', $this->codigo);
		$moneda = Tools::getValue('moneda', $this->moneda);
		$trans = Tools::getValue('trans', $this->trans);

		//$ssl = Tools::getValue('ssl', $this->ssl);
		//if ($ssl=='no')
		$urltienda = 'http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__.'modules/pagodigital/respuesta_tpv.php';
		//elseif($ssl=='si')
		//$urltienda = 'http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__.'modules/pagodigital/respuesta_tpv.php';
		//else
		//$urltienda = 'ninguna';

		$clave = Tools::getValue('clave', $this->clave);

		$clavePG =  Tools::getValue('clavepg', $this->clavepg);

		// Cálculo del SHA1 $trans . $urltienda
		
			$mensaje = $codigo . $clave . $clavePG;
		
			//$mensaje = $total . $numpedido . $codigo . $moneda . $clave;
			
			$firma = strtoupper(sha1($mensaje));

		$products = $params['cart']->getProducts();
		$productos = '';
		$id_cart = intval($params['cart']->id);

		//Activación de los idiomas del TPV
		/*$idiomas_estado = Tools::getValue('idiomas_estado', $this->idiomas_estado);
		if ($idiomas_estado=="si"){
			$ps_language = new Language(intval($cookie->id_lang));
			$idioma_web = $ps_language->iso_code;
			switch ($idioma_web) {
				case 'es':
				$idioma_tpv='001';
				break;
				case 'en':
				$idioma_tpv='002';
				break;
				case 'ca':
				$idioma_tpv='003';
				break;
				case 'fr':
				$idioma_tpv='004';
				break;
				case 'de':
				$idioma_tpv='005';
				break;
				case 'nl':
				$idioma_tpv='006';
				break;
				case 'it':
				$idioma_tpv='007';
				break;
				case 'sv':
				$idioma_tpv='008';
				break;
				case 'pt':
				$idioma_tpv='009';
				break;
				case 'pl':
				$idioma_tpv='011';
				break;
				case 'gl':
				$idioma_tpv='012';
				break;
				case 'eu':
				$idioma_tpv='013';
				break;
				default:
				$idioma_tpv='002';
			}
		}
		else {
			$idioma_tpv = '0';
		}
	*/
		$code1 = base64_encode ($codigo);
		$terminal1 = Tools::getValue('terminal', $this->terminal);
		$test = Tools::getValue('clave', $this->clave);
		$test5 = Tools::getValue('clavepg', $this->clavepg);
		$coded = base64_encode ($test);
		$coded1 = base64_encode ($terminal1);	 	 	
		$coded2 = base64_encode ($test5);
		 $value = $params['total_to_pay'];
                $valorBaseDevolucion = $params['objOrder']->total_paid_tax_excl;
                $iva = $value - $valorBaseDevolucion;
                //$valor = str_replace('.', '', $valor);
                if($iva == 0)$valorBaseDevolucion = 0;
	
		foreach ($products as $product) {
			$productos .= $product['quantity'].' '.$product['name'];
		}
		$customer = new Customer((int)($cart->id_customer));
			$smarty->assign(array(
			'idorder'=> ($cookie->logged ? $cookie->id_cart: false),
			'urltpv' => Tools::getValue('urltpv', $this->urltpv),
			'cantidad' => $cantidad,
			'moneda' => $moneda,
			'pedido' => $numpedido,
			'codigo' => $code1,
			'tipopago' => Tools::getValue('tipopago', $this->tipopago),
			'terminal' => $coded1,
			'clave' => $coded,
			'clavepg' => $coded2,
			'trans' => $trans,
			'merchantdata' => sha1($urltienda),
			'titular' => ($cookie->logged ? $cookie->customer_firstname.' '.$cookie->customer_lastname : false),
			'email' => ($cookie->logged ? $cookie->email: false),
			'iva' => $cart->getOrderTotal(true, Cart::BOTH) - $cart->getOrderTotal(false, Cart::BOTH),
            'total' => $cart->getOrderTotal(true, Cart::BOTH),
            'baseDevolucionIva' => $cart->getOrderTotal(false, Cart::BOTH),
            'nombre' => Tools::getValue('nombre', $this->nombre),
			'urltienda' => $urltienda,
			'notificacion' => Tools::getValue('notificacion', $this->notificacion),
			'productos' => $productos,
			'UrlOk' => 'http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__.'modules/pagodigital/pago_correcto.php',
			'UrlKO' => 'http://'.$_SERVER['HTTP_HOST'].__PS_BASE_URI__.'modules/pagodigital/pago_error.php',
			'firma' => $firma,
			'idioma_tpv' => $idioma_tpv,
			'this_path' => $this->_path,
			'fee' => number_format($fee, 2, '.', '')
		));
		return $this->display(__FILE__, 'pagodigital.tpl');
    }
    public function hookPaymentReturn($params)
	{
		if (!$this->active)
			return ;
		global $smarty;
		return $this->display(__FILE__, 'pago_correcto.tpl');
	}
}
?>