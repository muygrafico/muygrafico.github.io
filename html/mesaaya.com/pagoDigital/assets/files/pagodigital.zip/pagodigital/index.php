<?php 
if(!isset($_GET['paso'])){echo "Incluir Aviso de ACCESO NO PERMITIDO";}else{include "pD.PagosC1.php";}
?>