<?php


include(dirname(__FILE__).'/../../config/config.inc.php');
include(dirname(__FILE__).'/../../header.php');
include(dirname(__FILE__).'/pagodigital.php');

if (!empty($_POST)){

	// Recoger datos de respuesta
	$total     = $_POST["Ds_Amount"];
	$pedido    = $_POST["Ds_Order"];
	$codigo    = $_POST["Ds_MerchantCode"];
	$moneda    = $_POST["Ds_Currency"];
	$respuesta = $_POST["Ds_Response"];
	$firma_remota = $_POST["Ds_Signature"];
	
	// Creamos objeto
	$pagodigital = new pagodigital();
	//Verificamos opciones
	if ($respuesta == 'Negada') {
		
	$error_pago = 'si';
	
	}else{

	$error_pago = 'no';

	}
	// Contraseña Secreta
	$clave = Configuration::get('pagodigital_CLAVE');
	$idcliente = Configuration::get('pagodigital_CODIGO');
	$clavepg =  Configuration::get('pagodigital_CLAVEPG');
	// Cálculo del SHA1
	$mensaje = $codigo . $clave . $clavepg;
	$firma_local = strtoupper(sha1($mensaje));
		
	if ($firma_local == $firma_remota){
		// Formatear variables
		// NINO - eliminar el punto de los miles para evitar error en pago
		// ORIGINAL - $total  = number_format($total / 100,4);
		
		$totalG = $cart->getOrderTotal(true, Cart::BOTH);
		//$total = floatval($cart->getOrderTotal(true, 3));
		//$total  = number_format($total,0,",",".");
	 	$pedido = substr($pedido,0,8);
		$pedido = intval($pedido);
		$moneda_tienda = 1; 
				
		if ($respuesta == 'Aprobada'){
			
			// Compra válida
			
			$mailvars=array();
			$cart = new Cart($pedido);
			$pagodigital->validateOrder($pedido, _PS_OS_PAYMENT_, $totalG, $pagodigital->displayName, NULL, $mailvars, NULL, false, $cart->secure_key);		
			
			//$smarty->assign(array('this_path' => __PS_BASE_URI__));
			//$smarty->display(_PS_MODULE_DIR_.'pagodigital/pago_correcto.tpl');
			
			header ("Location: http://www.colombiatech.net/modules/pagodigital/pago_correcto.php");	

		}
		else {
			// Compra no válida
				

				header ("Location: http://www.colombiatech.net/modules/pagodigital/pago_error.php");

							//$smarty->assign(array('this_path' => __PS_BASE_URI__));			
							//$smarty->display(_PS_MODULE_DIR_.'pagodigital/pago_error.tpl');

			if ($error_pago=="no"){
				//se anota el pedido como no pagado	

				$pagodigital->validateOrder($pedido, _PS_OS_ERROR_, 0, $pagodigital->displayName, 'errores:'.$respuesta);
						
				}

			else if ($error_pago=="si"){		
								
				//Se permite al cliente intentar otra vez el pago
			
			}

		}
	
	}
	
	else {
		
		//se anota el pedido como no pagado
		
		//$pagodigital->validateOrder($pedido, _PS_OS_ERROR_, 0, $pagodigital->displayName, 'errores:'.$respuesta);
		
	}
}
?>
